// template = [
//     {
//         "header": "your header as HTML",
//         "description": "description goes here as HTML",
//     } ,... //multiple
// ]
const whats_new_log = [
    {
        "header": "Feature",
        "description": "Go live of <a href='https://dbeck121.github.io/CPI-Helper-Chrome-Extension'>Github Webpage</a>. Special thanks to <a href='http://github.com/incpi'>Omkar Patel</a>"
    },
    {
        "header": "Bugfixes",
        "description": "Some overall stability improvements."
    },
    {
        "header": "Feature",
        "description": "Small UI fixes"
    }
]

