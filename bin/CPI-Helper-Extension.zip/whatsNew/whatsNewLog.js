// template = [
//     {
//         "header": "your header as HTML",
//         "description": "description goes here as HTML",
//     } ,... //multiple
// ]
const whats_new_log = [
    {
        "header": "Improvement",
        "description": "Better payload viewer. Special thanks to <a href='http://github.com/incpi'>Omkar Patel</a>"
    },
    {
        "header": "Improvement",
        "description": "Go live of <a href='https://dbeck121.github.io/CPI-Helper-Chrome-Extension'>Github Webpage</a>. Special thanks to <a href='http://github.com/incpi'>Omkar Patel</a>"
    },
    {
        "header": "Bugfixes",
        "description": "Shows Content Enricher now in Inline Trace"
    },
    {
        "header": "Feature",
        "description": "Small UI fixes"
    }
]

