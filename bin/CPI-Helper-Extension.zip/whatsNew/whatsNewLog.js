// template = [
//     {
//         "header": "your header as HTML",
//         "description": "description goes here as HTML",
//     } ,... //multiple
// ]
const whats_new_log = [
    {
        "header": "Feature",
        "description": "New Timeline Plugin: Get overview about message flow. Thanks to Gregor Schütz from <a href='https://www.agilita.ch/'>AGILITA AG</a>"
    },
    {
        "header": "Feature",
        "description": "Create a project webpage on Github with improved structure and design. Special thanks to <a href='http://github.com/incpi'>Omkar Patel</a>"
    },
    {
        "header": "Bugfixes",
        "description": "Some overall stability improvements."
    },
    {
        "header": "Feature",
        "description": "Small UI fixes"
    }
]

