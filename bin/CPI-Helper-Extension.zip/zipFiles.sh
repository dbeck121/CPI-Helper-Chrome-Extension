rm -f ./bin/CPI-Helper-Extension.zip
zip -r ./bin/CPI-Helper-Extension.zip *
