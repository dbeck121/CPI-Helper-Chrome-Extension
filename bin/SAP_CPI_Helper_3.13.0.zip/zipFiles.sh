#!/bin/bash

echo "Copy readme to docs..."
cp README.md docs/readme/README.md
# copy paste readme root->docs

echo "Remove old zip file..."
rm -f ./bin/*.zip

# Read name and version from manifest.json
name=""
version=""
while IFS='' read -r line || [[ -n "$line" ]]; do
    if [[ "$line" == *"\"name\":"* ]]; then
        name=$(echo "$line" | awk -F'"' '{print $4}')
    elif [[ "$line" == *"\"version\":"* ]]; then
        version=$(echo "$line" | awk -F'"' '{print $4}' | tr -d ',')
    fi
done < manifest.json

# Replace comma , space with underscore in name
name="${name//,/}"
name="${name// /_}"

# Zipping files excluding those starting with 'docs/' or '.'
echo "Zipping files..."
find . -type f ! \( -path "./docs/*" -o -path "./.*" \) -exec zip -r "bin/${name}_${version}.zip" {} +