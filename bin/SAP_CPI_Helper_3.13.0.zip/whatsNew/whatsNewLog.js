// template = [
//     {
//         "header": "your header as HTML",
//         "description": "description goes here as HTML",
//     } ,... //multiple
// ]
const whats_new_log = [
    {
        "header": "Improvement",
        "description": "Better payload viewer. Special thanks to <a target='_blank' href='http://github.com/incpi'>Omkar Patel</a>"
    },
    {
        "header": "Improvement",
        "description": "Go live of <a target='_blank' href='https://dbeck121.github.io/CPI-Helper-Chrome-Extension'>Github Webpage</a>. Special thanks to <a target='_blank' href='http://github.com/incpi'>Omkar Patel</a>"
    },
    {
        "header": "Bugfixes",
        "description": "Shows Content Enricher now in Inline Trace"
    },{
        "header": "Bugfixes",
        "description": "UI Icon are changed + UI Bugfixes"
    },
    {
        "header": "Feature",
        "description": "Regex/ find /replace featured added with Ctrl + F (find) in formatted payload(Trace body tab)."
    },
    {
        "header": "Feature",
        "description": "UI Icon changed, Resize Body from Content modifier,Regex/ find /replace featured added with Ctrl + F (find) in formatted payload(Trace body tab)."
    },
    {
        "header": "Feature",
        "description": "Once trace expired, no popup will be shown instead warning will be given."
    }
]