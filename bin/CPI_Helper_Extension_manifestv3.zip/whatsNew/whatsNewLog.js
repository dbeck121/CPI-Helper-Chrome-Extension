// template = - [header :your header as HTML] [description": "description goes here as HTML] ,... //multiple
const whats_new_log = `
- [Fix] Persist message downloads now have meaningful filenames
- [Fix] Some small ui bugs
- [Fix] Better error handling when fetching api messages
`;
