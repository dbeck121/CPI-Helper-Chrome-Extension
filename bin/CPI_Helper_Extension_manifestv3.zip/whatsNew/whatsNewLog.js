// template = - [header :your header as HTML] [description": "description goes here as HTML] ,... //multiple
const whats_new_log = `
- [Plugin] Connectivity Credentials Manager - Save, load, and manage connection profiles for SAP CPI connectivity tests. Special thanks to <a href="https://github.com/vbalko-claimate" target="_blank">Vladimir Balko</a>.
- [Fix] Message sidebar now correctly shows only messages from the current iFlow when switching between tabs or iFlows
`;
