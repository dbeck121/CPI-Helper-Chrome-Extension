// template = - [header :your header as HTML] [description": "description goes here as HTML] ,... //multiple
const whats_new_log = `
- [Plugin] iFlow Searcher - Highlight Content Modifier and Scripts with key words.
- [Improvement] Less load on backend
- [Improvement] Optimized reload button in message sidebar
- [Feature] Toggle to shut off auto reload
- [Fix] Problem with visited packages in popup
`;
