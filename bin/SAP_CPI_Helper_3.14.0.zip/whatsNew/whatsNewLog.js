// template = [
//     {
//         "header": "your header as HTML",
//         "description": "description goes here as HTML",
//     } ,... //multiple
// ]
const whats_new_log = [    

    
    {
        "header": "Maintenance",
        "description": "Update to Manifest V3. This is a major and necessary under the hood update and may cause some issues. Please report any issues."
    },
    {
        "header": "Plugin",
        "description": "Get Message ID logs Plugin to get logs from message ID in message sidebar."
    },
    {
        "header": "Plugin",
        "description": "Apache Camel Update Message Remover Plugin (Beta). Get rid of annoying Apache Camel update message. This plugin is in beta and may not work in all cases. Please report."
    }
    {
        "header": "Improvement",
        "description": "CPI Helper survives login procedure and does not need reload after login (beta)"
    }
 
]