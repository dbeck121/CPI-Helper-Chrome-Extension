// template = - [header :your header as HTML] [description": "description goes here as HTML] ,... //multiple
const whats_new_log = `   
- [Fix] Solved problem with activating trace (on non-Edge Cell and Edge Cell tenants).
- [Fix] Could not beautify logs in some cases
`;
